<!-- </div>
    <footer class="bg-white shadow mt-8 py-4">
        <div class="container mx-auto px-4 text-center">
            <p class="text-gray-600">© 2025 LinkedIn Clone. All rights reserved.</p>
        </div>
    </footer>
    <script src="js/scripts.js"></script>
</body>
</html> -->